<?php

namespace App\Http\Controllers\institutions;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class getInstitution extends Controller
{
    //
    public function get_institution()
    {
        return "hello";
    }
}
